
import { useState } from 'react';

const PlantAnalysis = () => {
  const [image, setImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [analysisResult, setAnalysisResult] = useState(null);

  // Handle image upload
  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  // Dummy analysis function (to be replaced with actual AI model later)
  const analyzeImage = () => {
    // Placeholder for analysis
    setAnalysisResult("التحليل: النبات في حالة جيدة - لا توجد مشاكل كبيرة.");
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-8">
      <h1 className="text-4xl font-bold mb-6">تحليل النبات بالصورة</h1>
      <p className="text-lg text-center max-w-xl mb-8">
        قم بتحميل صورة للنبات لتحليل حالته.
      </p>
      
      <input 
        type="file" 
        accept="image/*" 
        onChange={handleImageUpload} 
        className="mb-4 p-2 border border-gray-300 rounded"
      />
      
      {imagePreview && (
        <div className="mb-6">
          <img src={imagePreview} alt="معاينة الصورة" className="max-w-md" />
        </div>
      )}

      <button 
        onClick={analyzeImage} 
        className="bg-green-500 text-white p-4 rounded-xl shadow hover:bg-green-600"
      >
        تحليل الصورة
      </button>

      {analysisResult && (
        <div className="mt-8 bg-yellow-100 p-4 rounded-lg">
          <h2 className="font-semibold text-lg">نتيجة التحليل:</h2>
          <p>{analysisResult}</p>
        </div>
      )}
    </div>
  );
};

export default PlantAnalysis;
