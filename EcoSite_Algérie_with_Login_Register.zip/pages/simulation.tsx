
import { useState } from 'react';

const EcosystemSimulation = () => {
  const [years, setYears] = useState(1);
  const [result, setResult] = useState(null);

  const handleSimulate = () => {
    // Placeholder simulation result
    setResult(\`تمت المحاكاة لمدة \${years} سنة. تظهر النتائج تغيرات بيئية تدريجية مع إدخال النوع.\`);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-8">
      <h1 className="text-4xl font-bold mb-6">محاكاة الأنظمة البيئية</h1>
      <p className="text-lg text-center max-w-xl mb-8">
        اختر عدد السنوات لمراقبة تأثير إدخال نوع جديد على النظام البيئي.
      </p>

      <input 
        type="range" 
        min="1" 
        max="30" 
        value={years} 
        onChange={(e) => setYears(e.target.value)} 
        className="w-full max-w-md mb-4"
      />
      <p className="mb-4">عدد السنوات: {years}</p>

      <button 
        onClick={handleSimulate} 
        className="bg-blue-600 text-white px-6 py-3 rounded-lg shadow hover:bg-blue-700"
      >
        بدء المحاكاة
      </button>

      {result && (
        <div className="mt-8 bg-green-100 p-4 rounded-lg max-w-md text-center">
          <h2 className="font-semibold text-lg">نتيجة المحاكاة:</h2>
          <p>{result}</p>
        </div>
      )}
    </div>
  );
};

export default EcosystemSimulation;
