
const ecosystems = [
  {
    name: "الغابات المتوسطية",
    description: "تتميز بتنوع نباتي كبير، مثل البلوط والصنوبر، وتعد موطنًا للعديد من الطيور والثدييات.",
  },
  {
    name: "الصحراء الكبرى",
    description: "بيئة قاحلة تحتوي على أنواع متكيفة مع الجفاف مثل النخيل، وبعض الزواحف والثدييات الصغيرة.",
  },
  {
    name: "السهوب",
    description: "تغطي مناطق واسعة وتضم نباتات عشبية وشجيرات، وتعد بيئة مناسبة للرعي.",
  },
  {
    name: "المنطقة الساحلية",
    description: "تجمع بين الغابات والمسطحات المائية، وتتميز بتنوع نباتي وحيواني كبير.",
  },
];

const EcosystemInfo = () => {
  return (
    <div className="p-8">
      <h1 className="text-4xl font-bold text-center mb-8">الأنظمة البيئية في الجزائر</h1>
      <p className="text-center text-lg mb-10 max-w-3xl mx-auto">
        تعرف على الأنظمة البيئية الأساسية في الجزائر، ومميزاتها والأنواع البيولوجية المنتشرة فيها.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {ecosystems.map((eco, index) => (
          <div key={index} className="bg-white rounded-xl shadow p-6 border hover:shadow-lg transition duration-300">
            <h2 className="text-2xl font-semibold mb-2">{eco.name}</h2>
            <p className="text-gray-700">{eco.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EcosystemInfo;
